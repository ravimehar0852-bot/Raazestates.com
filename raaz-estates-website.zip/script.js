window.addEventListener("load", ()=>{
  document.querySelector(".loader").style.display = "none";
});

const topBtn = document.getElementById("topBtn");

window.addEventListener("scroll", ()=>{
  if(window.scrollY > 400){
    topBtn.style.display = "block";
  } else{
    topBtn.style.display = "none";
  }
});

topBtn.addEventListener("click", ()=>{
  window.scrollTo({
    top:0,
    behavior:"smooth"
  });
});

document.querySelector(".contact-form").addEventListener("submit",(e)=>{
  e.preventDefault();
  alert("Thank you! Your enquiry has been submitted.");
});
